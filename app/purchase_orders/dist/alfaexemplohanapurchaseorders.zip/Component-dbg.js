sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("alfa.exemplo.hana.purchaseorders.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);